from abc import ABC, abstractmethod
from typing import List

import pandas as pd
from abc import ABC, abstractmethod
from typing import List
import pandas as pd
import subprocess
import os
import docx
from .Ingestor import Ingestor
